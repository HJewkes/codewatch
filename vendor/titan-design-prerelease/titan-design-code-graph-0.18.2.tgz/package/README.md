# @titan-design/code-graph

The dependency graph of a TypeScript or Python tree: files, modules, exported and internal
symbols, external packages, and the import / re-export / reference edges between them, with
index-time source metrics, in one SQLite file built from `@titan-design/store-sqlite` kit
tables and refreshed incrementally.

Tier 2 of the titan-platform DAG. Depends on `store-sqlite`, `code-parser` (tree-sitter WASM
parsing and the file filter), `ts-morph`, `web-tree-sitter` for node types, and `embed` plus `retrieval` for similar-symbol search. Extracted from codewatch's `@codewatch/graph` (TP-9), split along the seam the
audit identified: that package did the job of both a store and a code graph.

```ts
import { indexPaths, listEdges, listNodes, openCodeGraph } from "@titan-design/code-graph";

const store = openCodeGraph(".codewatch/graph.db");
const { snapshotId, files, nodes, edges, reused } = await indexPaths(store, {
  paths: ["packages", "products"],
  ref: "head",
});
listNodes(store, snapshotId); // file / module / external nodes, symbols on request
listEdges(store, snapshotId); // imports / re-exports, references and calls on request
```

`IndexResult.warnings` is present only when git was found but its history log overflowed or
failed, so the snapshot has no (or partial) history metrics. It is absent when history loaded
and outside git. `assembleIndexerMetrics` returns `{ metrics, warnings }`;
`buildIndexerMetrics` keeps returning the metrics alone.

## What was extracted, and what was not

In: the parser (tree-sitter WASM for TypeScript, TSX and Python, since moved to
`@titan-design/code-parser` and still re-exported here), the walk, the ts-morph
extractor and its symbol layer, role classification, generated-file detection, id aliasing
across git renames, the three-tier incremental reuse, and the metrics computed at index time
(degree, utilization, loc, cyclomatic, cognitive, nesting, class count, lcom4, and per
symbol `symbol_cognitive`, `symbol_cyclomatic`, `symbol_loc`, `symbol_max_nesting`, and the
comment and shape metrics below). `lcom.ts` came along despite being an analysis: `source-metrics.ts` calls it
directly and lcom4 is a pure function of a file's bytes, so it belongs with the metrics that
carry forward under reuse.

Ported later (TP-123, TP-124), strictly as codewatch had them: the rules engine
(`check*.ts`, now `src/check/`) and the snapshot diff plus check diff (`diff.ts`,
`check-diff.ts`, now `src/diff/`). See [Checks and diffs](#checks-and-diffs).
Ported with TP-127 and TP-128: dead code, growth risk, PageRank, relevance, and symbol
coupling, now `src/analysis/`. See [Graph analyses](#graph-analyses).
Ported with TP-133: the test linker and the Istanbul coverage overlay, also in `src/analysis/`,
and test-coverage ownership. See [Test linking and coverage](#test-linking-and-coverage).

Ported with TP-250: package partition quality (`src/analysis/partition-quality.ts`) and
snapshot pruning (`src/prune.ts`). See [Partition quality](#partition-quality) and
[Pruning snapshots](#pruning-snapshots).

Ported with TP-130: community detection and the convention layer (`src/conventions/`). See
[Conventions](#conventions). codewatch keeps the CLI command, the `claude -p` summarizer, and
the MCP and read-API wiring.

Deferred, still in codewatch, a follow-up on this package rather than a change to it:

- Reuse-delta reporting over a finished snapshot.

Python support is new here rather than ported. codewatch walked TypeScript only; the parser
already had the grammar. The Python extractor is deliberately narrower than the ts-morph one:
no type checker, so imports resolve by dotted path against the tree and symbols come from the
same tree-sitter declaration walk that feeds complexity.

## The id scheme

File, module and external ids are preserved exactly from codewatch, because this repo's own
`dag:check` consumes them through codewatch's CLI. Symbol ids diverge from codewatch since
index version 0.14.0:

- A **file** id is its path relative to the git toplevel, in posix form:
  `packages/registry/src/index.ts`. Ids root at the git toplevel even when you walk a
  subtree, so importers across subtrees share one id space.
- A **module** id is the file id minus its extension: `packages/registry/src/index`. Its
  parent is the directory above it.
- A **symbol** id hangs under its declaring file as `<fileId>#<qualifiedName>`, split on the
  first `#`. A top-level declaration's qualified name is its own name
  (`src/a.ts#createThing`). A member or nested declaration is prefixed by its enclosing named
  scopes, joined with `.`: `src/a.ts#Job.run`, `src/a.ts#outer.helper`, and
  `src/a.ts#handlers.onClick` for a method of `const handlers = {…}`. An unbound callback
  argument, object or class expression adds one `<anonymous>` segment, and consecutive
  anonymous scopes collapse to one, so
  `src/a.ts#App.<anonymous>.onHash` is a function declared inside a callback in `App`. The
  segment keeps it apart from a member `App.onHash`, and ids do not depend on declaration
  order. One scope binds a name once: a getter/setter pair, a Python property's
  accessors, and overloads each share one node. Index versions before 0.14.0 keyed members by
  bare name, so same-named methods in one file collapsed into one node (TP-182).
- An **external** id is `npm:<package>` (scope-aware) or the `node:` builtin verbatim.

`NodeKind` and `EdgeKind` are unchanged, and the `role` vocabulary only grew (see
[File roles](#file-roles)). So is the property the DAG
check rests on: an import of a workspace package by its published name resolves to that
package's source file, not to an `npm:` external, by remapping the `dist/*.d.ts` entry
ts-morph resolves back onto `src/`. That remap needs the target package built, which is why
`pnpm build` precedes both `pnpm test` and `dag:check`.

## File roles

Every file and module node carries a `role`, one of `ALL_ROLES`: `test`, `fixture`, `story`,
`lab`, `barrel`, `types`, `config`, `script`, `entry`, `generated` and `source`. The first
match wins, in this order:

1. `generated`: a `.gitattributes linguist-generated` path or a `*.gen.*`/`generated/` path.
2. A configured glob from `.codewatch/roles.json` (below).
3. `test`, then `story` (`*.stories.{js,jsx,ts,tsx}` with an optional `c`/`m`, and `*.mdx`),
   so a story under `fixtures/` is still a story.
4. `fixture` (a `fixtures/` path or a `*.fixture.*` or `*.fixtures.*` file), `script`, `entry` (a `#!` shebang), `barrel`, `types`, `config`, else `source`.

`UNIMPORTED_ROLES` lists the roles nothing imports by design (`test`, `fixture`, `story`, `lab`,
`config`, `script`, `entry`). Dead-module reachability seeds from them plus `barrel`.

`lab` has no built-in rule, since a `lab/` directory name is too generic to guess. A repo
assigns it, or any other role, with `.codewatch/roles.json`, which maps roles to
`.gitattributes`-style globs matched against file ids:

```json
{ "lab": ["packages/ui/src/lab/**"] }
```

`loadRoleGlobs(repoRoot)` reads that file (an absent file configures nothing, an unknown role
throws), and `computeRoleHints` passes the result to `annotateRoles` as `roleGlobs`. `story`,
`lab` and roles.json arrived in index version 0.21.0.

## Identity across renames

Added in index version 0.15.0 (TP-187). Git rename detection writes `id_alias` rows mapping a
file's and its module's old id to the new one. A file rename also writes an alias for every
symbol present on both sides, so `a.ts#Job.run` follows `a.ts` to `b.ts#Job.run`. A symbol
renamed inside a file is not followed.

Each snapshot records its alias base in `attrs.aliasBase`: the snapshot whose commit its
aliases were computed against. A new index of a ref diffs against that ref's newest committed
snapshot, falling back to the newest committed snapshot of any ref. The bases form a tree, so
ids can be carried between any two snapshots that share an ancestor, forward or backward.

```ts
import { aliasChain, priorSnapshotForRef, resolveAlias } from "@titan-design/code-graph";

resolveAlias(store, "src/job.ts", 4, { fromSnapshotId: 1 });
// { id: 'core/worker.ts', reason: 'move',
//   hops: [ src/job.ts -> src/task.ts, src/task.ts -> src/worker.ts, src/worker.ts -> core/worker.ts ] }
resolveAlias(store, "src/job.ts#Job.run", 4, { fromSnapshotId: 1 }).id; // 'core/worker.ts#Job.run'
aliasChain(store, 1, 4).resolve; // one resolver for many ids
priorSnapshotForRef(store, "main", { before: 7, repoRoot: "." }); // the snapshot main denotes
```

Without `fromSnapshotId`, `resolveAlias` walks from the root of the target's lineage, so an id
from any ancestor resolves. Each snapshot's aliases are applied once, in order: they come from
one git diff, so `a.ts` to `b.ts` plus `b.ts` to `a.ts` in one snapshot is a swap, not a
cycle. Walks stop after 10,000 snapshots. Two snapshots with no common base fall back to the
to-snapshot's own aliases, which is what `diffSnapshots` did before 0.15.0.

`priorSnapshotForRef` prefers the snapshot of the commit git resolves the ref to, and
otherwise the newest snapshot labelled with that ref. A snapshot written before 0.15.0 records
no base; its base is inferred as the newest earlier snapshot with a commit, which is the one
the 0.14.0 indexer diffed against. Nothing is written on read, so a 0.14.0 store opened
read-only diffs and checks across renames too.

## The three reuse tiers

Every run writes a fingerprint per file: a content hash and a comment/whitespace-insensitive
hash of its parse structure. The next run diffs against the most recent snapshot carrying the
same `INDEX_VERSION` and sorts each file into one tier. `INDEX_VERSION` is bumped whenever a
metric can change for the same bytes, not only when the node or edge shape changes: 0.12.0
marks `.tsx` files moving to the tsx grammar, which changed their complexity metrics and
symbol spans; 0.13.0 marks the dead-code and growth-risk metrics joining the carry-forward set;
0.14.0 marks symbol ids qualified by their enclosing scopes (TP-182); 0.15.0 marks symbol
aliases on a file rename and the recorded alias base (TP-187). A snapshot from an older version
is never reused, so the first run after an upgrade is a full index. The first 0.14.0 run after
an older snapshot writes `requalify` id aliases from each bare-name id to its qualified
successor, only where exactly one declaration in the file carries that name.

| Tier | Trigger | Work skipped |
|---|---|---|
| reuse | content hash matches | parse and extract both; nodes, edges and source metrics carried forward verbatim |
| cosmetic | content changed, structural hash matches | the ts-morph extract; edges come from the basis, symbol line spans are refreshed from the fresh parse |
| full | structural hash changed, or the file is new | nothing |

A file-membership delta (a file added or removed) forces the files whose imports it
re-resolves back to full extraction even when they are byte-identical. Degree metrics are
always recomputed over the whole assembled graph, so a heavily-reused run and a
`incremental: false` run produce the same snapshot; `incremental-index.test.ts` asserts that.

## Store layout

`openCodeGraph` opens the database with the kit's pragmas and runs four migrations.

It refuses a database stamped past `SCHEMA_VERSION` with `SchemaTooNewError`: a code graph
database belongs to one build, so a higher version means a newer build already moved the
schema and this one would query columns that are gone.

Kit tables: `snapshot` (the snapshot registry), `node` (`entity_snap`, keyed
`(snapshot_id, id)`), `blob_cache` (content-addressed, for the embedding and summary caches
an analysis layer will want). Migration 2 adds four columns the kit shapes do not carry but
every consumer reads directly: `node.language`, `node.role`, `snapshot.commit_hash`,
`snapshot.index_version`.

Domain tables in `schema.ts`: `edge` (snapshot-scoped, keyed
`(snapshot_id, src_id, dst_id, kind)` — the kit's own edge table is bi-temporal, which is the
wrong time model for a population re-indexed all at once), `metric`, `id_alias`, and
`file_fingerprint`. Migration 4 adds `finding` and `verdict`, both keyed
`(snapshot_id, key)` on a `findingKey` and pruned with their snapshot.

The symbol layer is hidden by default. `listNodes` drops `symbol` nodes and `listEdges` drops
`references` and `calls` edges unless you ask for them (`includeReferences` covers both), so a caller reasoning about module structure sees
the graph it expects and does not have one import of thirty names read as thirty
dependencies.

## Targeted reads and the metric catalogue

Added for the read API (TP-183). Three store reads answer one node or one metric without
loading a snapshot, and a catalogue describes every metric name the package writes.

```ts
import { aggregateMetrics, describeMetric, listEdgesTouching, listMetricsForNode } from "@titan-design/code-graph";

listMetricsForNode(store, snapshotId, "packages/registry/src/invoke.ts"); // every metric on one node
listEdgesTouching(store, snapshotId, "packages/registry/src/invoke.ts"); // edges in and out; references on request
aggregateMetrics(store, snapshotId, { name: "loc" }); // [{ name: "loc", nodeKind: "file", count, sum, min, max }]
describeMetric("churn_90d"); // { unit: "lines", rollup: "sum", direction: "neutral", absent: "zero", window: "90d", … }
```

Three more store reads answer a report's questions without loading a snapshot:
`listMetricNames(snapshotId)` for the distinct names stored, `topByMetric({ snapshotId,
metric, limit, kind })` for the highest-valued nodes joined to their kind and role, and
`replaceMetricsByName(snapshotId, name, metrics)`, which swaps one metric's whole row set in
a single transaction so a re-ingested overlay such as coverage never accumulates stale rows.

`computeDeepAst({ filePath, absPath, symbolName })` reads structure too heavy to persist
(params, return type, class members) from the working tree on demand, and returns null when
the file is unreadable.

- **Reads.** `listMetricsForNode` searches the metric primary key, `listEdgesTouching` the edge
  primary key plus `idx_edge_dst`, and `aggregateMetrics` `idx_metric_name`. None scans a
  table, and no index or migration was added, so any existing store serves them. A self-loop
  comes back once. `aggregateMetrics` groups by metric name and node kind, because
  `utilization` and the degree metrics sit on several kinds; `count` skips null values.
- **Catalogue.** `METRIC_CATALOGUE` holds one `MetricDescriptor` per name: `unit`,
  `appliesTo` (node kinds), `rollup` (`sum`, `max`, `mean`, or `none`), `direction`
  (`higher-worse`, `lower-worse`, or `neutral`), `absent`, `source`, and `description`.
  Windowed names are templates such as `churn_{w}`; `describeMetric` resolves a stored name
  such as `churn_90d` or `test_bus_factor_lifetime` to a concrete descriptor, and returns
  null for a name nothing writes.
- **`rollup: "none"`** means no rollup reproduces the group's own value. Summing fan-in counts
  a directory's internal edges, and summing per-file commit counts counts a shared commit
  more than once. A reader must not synthesize those.
- **`absent`** says what a missing row means. `zero`: the writer is sparse, so count the node
  as zero (dead code, growth risk, churn, `linked_test_count`). `exclude`: the metric does not
  apply or was not measured (a max over no functions, `coverage_pct` before ingest), so leave
  the node out of means, percentiles, and ranks.
- **Completeness is tested.** `catalogue-completeness.test.ts` indexes a fixture repo with
  history and a coverage overlay, and fails, naming the metric, when a stored name has no
  descriptor, when a descriptor's unit or node kinds disagree with the rows, or when a
  descriptor matches nothing.
- **Browser-safe.** The catalogue imports only `types.ts`. The `code-graph-catalogue-pure`
  and `code-graph-catalogue-no-node` rules in `.codewatch/check.json` hold it there, so a
  later browser subpath can re-export it. It ships from the root export today, which does
  pull in Node.

## Checks and diffs

The rules engine turns a snapshot into pass/fail against a `check.json`. Eight rule types:
`metric-max`, `metric-min`, `metric-product-max`, `metric-outlier`, `forbid-import`,
`layered-deps`, `no-internal-only-barrels`, and `no-import-cycles`. Severity defaults to `error`; only new errors
fail a check. `layered-deps` takes `excludeRoles`: an import is dropped when its source or
destination file has an excluded role, and `exemptTypeOnly: true` drops an edge whose every
import from that file is `import type` (off by default; a file that also imports a value, or
writes an all-inline `{ type T }`, still counts). `forbid-import` takes `except`: destination patterns
that `to` matches but the rule allows, such as one sanctioned entry file.

`no-import-cycles` reports each strongly connected component of the file import graph once,
as one violation whose `members` are the cycle's files, sorted; a file importing itself is a
cycle of one. `import type` and `export type … from` edges are left out unless
`includeTypeOnly: true`. An all-inline `{ type T }` import still counts, because under
`verbatimModuleSyntax` it compiles to an import that loads the module. `exclude` and
`excludeRoles` take files out of the graph.
Each cycle carries `cycleKind`: `value` when its value imports alone still close a cycle among
its members, otherwise `type-only`. A type-only cycle also names its `hub`, the member with the
most type-only imports in from the other members, and its evidence says so.
The baseline key is the rule id plus every member, so it does not depend on edge order. Against
a baseline, a cycle whose members all sit inside one known cycle is a carryover, so a shrunk or
split cycle passes, while a cycle that gains a file or merges two known cycles is new.

Validation rejects a rule whose `severity` is anything but `error` or `warning`, whose `kind`
is not a node kind (`package`, `module`, `file`, `symbol`, `external`), or whose `exclude` is
not an array of strings. Each of those mistakes used to load silently and disable the rule:
`"Error"` counted as a warning, `"files"` matched no node, and a string `exclude` was dropped.

`metric-outlier` takes its threshold from the snapshot instead of the rule:
`{ "type": "metric-outlier", "id": "long-fn", "metric": "symbol_body_lines", "kind": "symbol", "percentile": 95 }`
flags every symbol strictly above the 95th percentile of `symbol_body_lines` over all symbols
that carry it, interpolated linearly between ranks. `percentile` runs from 50 to 100. The rule
stays silent until `minSample` nodes (default 20) carry the metric. Each violation's
`threshold` is the computed percentile value. For sparse metrics whose percentile sits at or
near zero, `floor` flags a node only if its value also exceeds that absolute number, and
`rankNonZero: true` ranks and gates on non-zero carriers only.

```ts
import { checkSnapshot, loadCheckRules, openCodeGraph } from "@titan-design/code-graph";

const store = openCodeGraph(".codewatch/graph.db");
const rules = await loadCheckRules(".codewatch/check.json", { onWarn: console.warn });
const { result } = checkSnapshot(store, { snapshot: "head", baseline: "main", rules });
result.passed; // false only when a violation is an error and absent from the baseline
```

`snapshot` and `baseline` take a numeric snapshot id or a ref name; a ref resolves to its
newest snapshot. `runChecks(store, { snapshotId, rules, baselineSnapshotId })` is the same
engine on ids, and `validateRules(json)` validates an already-parsed rules object.

The baseline is a ratchet. A violation whose key (rule id, node id, and destination id for
edge rules) also fires on the baseline snapshot is marked `isCarryover` and counts as
carryover, so existing debt does not block a change but new debt does. The baseline's node ids
are first carried through the alias chain into the checked snapshot (`rebasedViolationKey`),
so a moved file's violations carry over instead of reading as one resolved plus one new.
Unmoved ids key exactly as `violationKey` always did. Deprecated metric and
role spellings in a rules file (`lines`, `tests`) heal to their canonical names with a
warning through `onWarn` instead of failing validation.

`diffSnapshots(store, { fromSnapshotId, toSnapshotId })` reports added, removed and renamed
nodes, added and removed edges, and metric deltas on nodes present in both. Ids follow the
alias chain between the two snapshots, across every rename in between, so a move reads as a
rename rather than a delete plus an add, and its edges do not churn. Metric and edge-kind spellings are
canonicalised before comparing.

`diffCheckResults(store, { fromSnapshotId, toSnapshotId, rules })` runs the rules on both
snapshots and buckets each violation as new, resolved, or unchanged. Unchanged metric
violations are further split into worsened and improved, where
worsened means further past the threshold: a rising value on a maximum, a falling one on a
minimum such as `coverage_pct`. `violationExcess(ruleType, value, threshold)` is that measure, value over
threshold for a maximum and threshold over value for a minimum, and `compareExcess(before,
after)` names the direction. A pair whose excess is null on either side, because the value
or threshold is missing, or a maximum or a minimum rule's value is 0 or less, is neither
worsened nor improved. `delta` stays the raw value difference. From-side ids follow the
alias chain, as in the ratchet.

`computeFootprints({ nodes, edges }, options)` gives each symbol node a footprint built from
structural inputs only, so a moved declaration or a churn window never reads as a change. It
has three parts, each a `hashText` over canonical JSON: `signature` (name, exported, signature,
purpose; no span), `consumers` (sorted distinct files with a `references` edge into the symbol),
and `coupling` (sorted co-import partners at or above `minCoImports`, default 2). `hash` combines
the three. Consumers include test files unless `ignoreConsumer(fileId)` rejects them; a rejected
file is dropped from coupling too. `symbolSetHash({ unitId, symbolIds }, footprints)` hashes a
doc unit's sorted `[symbolId, footprint.hash]` pairs, so it ignores member order and changes when
a member is added, removed or changed.

`diffFootprints(store, { fromSnapshotId, toSnapshotId, ...options })` compares the footprints of
two snapshots. From-side ids follow the alias chain first, and a symbol under a moved file follows
its file, so a move reads as `changed` with `reasons: ["renamed"]` alone when its footprint held.
Each other change is `added`, `removed`, or `changed` with the differing parts (`signature`,
`consumers`, `coupling`). `files` rolls the changes up to their declaring files, never to consumers.

`scripts/dag-check-self.mjs` in the repo root runs this repo's DAG check on this engine
instead of codewatch's CLI.

The glob matching the rules use is exported too, because a CLI filters its own `--include`
and `--exclude` flags with the same semantics: `patternToRegex` (a `*` glob when the pattern
holds one, a case-sensitive substring otherwise), `compilePatterns`, and `matchesAny`.

## Similar symbols

Ported from codewatch's `embeddings.ts` (TP-129). It answers "does something like this
already exist?" before you write it. The embedder is injected; this package never builds
one and never talks to a network on its own.

```ts
import { OllamaEmbedder } from "@titan-design/embed";
import { findSimilarCapability, tryEmbedSnapshot } from "@titan-design/code-graph";

const embedder = new OllamaEmbedder();
const attempt = await tryEmbedSnapshot(store, snapshotId, embedder);
// { ok: true, result: { symbols, embedded, withPurpose, newlyEmbedded, reused, model } }
// or { ok: false, model, error } when the backend is down; the snapshot is unaffected
const { candidates, coverage } = await findSimilarCapability(store, snapshotId, "parse a duration", embedder);
```

- **Corpus.** Exported symbols with a signature, minus test, fixture and generated files.
  The embedded text is `signature -- purpose` (the docstring), never the body.
- **Storage.** Vectors go in `blob_cache` under namespace `code-graph/symbol-embedding`,
  keyed by `embedder.model` and the SHA-256 of the text. They are not snapshot-scoped, so
  re-embedding unchanged text costs zero embed calls. `embedSnapshot` throws on a backend
  failure; `tryEmbedSnapshot` reports it.
- **Query.** `vectorRetriever` over a `BruteForceVectorIndex` from `retrieval`. The query is
  embedded with role `query` and the symbol texts with role `document`; the embedder applies
  the matching prefix (`search_query: ` / `search_document: ` for nomic models).
- **Results are candidates, not verdicts.** Each has a cosine score, and `coverage` says how
  many symbols were searchable and how many carry purpose text. There is deliberately no
  co-location filter.
- **Python symbols are not in the corpus yet.** The Python extractor records no signature or
  docstring, so no Python symbol passes the corpus filter.
- **Prefixes are part of the cache key.** `embedder.model` includes a hash of the embedder's
  prefix table, so two prefix configurations never share a vector. codewatch used no prefix;
  `new OllamaEmbedder({ prefixes: { document: "", query: "" } })` reproduces its rankings.

## Graph analyses

Dead-code and growth-risk metrics are computed at index time, like the source metrics, and
carry forward for unchanged files. Both are sparse: a file gets a row only when a count is
above zero.

- Dead code, TypeScript and Python: `unreachable_statements` (after a `return`, `throw` or
  `raise`, `break` or `continue` in the same block), `unused_locals`, and `unused_params`
  (trailing run only). Python skips `self`, `cls`, `_`-prefixed names, `global` and
  `nonlocal` names, and the parameters of stub bodies such as `@overload` signatures; a
  `*args` or `**kwargs` ends the trailing run.
- Growth risk, TypeScript and Python: `loop_depth` (at 2 or more), `recursive_functions`,
  and `search_in_loop` (`.includes`, `.find` and similar inside a loop). These are smells,
  not complexity bounds. Recursion and search match TypeScript call nodes only, so Python
  files get `loop_depth` alone, as in codewatch.

Comment, shape, and exception-handling metrics (TP-322) are also source-local, TypeScript and
Python, and are written on every function or file, zeros included:

- Per symbol: `symbol_comment_lines` (rows holding a comment inside the function, docstring
  excluded), `symbol_docstring_lines` (the Python docstring, or a JSDoc block ending on the row
  above the declaration), `symbol_body_lines` (rows holding code), `symbol_comment_ratio`
  (comment lines over `max(body lines, 1)`), `symbol_narrating_comments` (comments whose words
  share at least 2 tokens, or half their tokens, with the identifiers of the statement they sit
  above or trail), and `symbol_pass_through` (1 when the body is one call that forwards every
  parameter, in order, as a bare argument, skipping a `self` or `cls` receiver; a function
  with no parameters is never one).
- Per component (a PascalCase function that renders JSX; props resolve within the file only,
  absent when the props type is imported or untyped): `symbol_prop_count` (own-declared
  props), `symbol_bool_prop_count` (those typed `boolean`) and `symbol_unread_props` (those
  the body never reads; 0 when `...rest` or the whole props object is forwarded).
- Per file: `except_count` (Python `except` and TypeScript `catch` clauses), `except_density`
  (per 100 non-blank lines), and `swallowed_except` (handlers whose body is empty, `pass`,
  `...`, `continue`, a bare or `None`/`null`/`undefined` return, or one call to a logger,
  `print`, `warn` or `console`).
- Per file, line density (TP-2474): `long_line_share_160` (share of non-blank lines over 160
  characters), `chars_per_sloc` (characters per non-blank line, surrounding whitespace
  excluded) and `bool_ops_per_line` (syntax-tree `&&`, `||`, `??` and ternaries, or Python
  `and`, `or` and conditional expressions, per non-blank line; strings and comments never
  count).

Call-graph metrics (TP-323) come from `calls` edges, one per caller and callee symbol, each
carrying the literal arguments of every call site in `attrs.sites`. TypeScript resolves a
call or `new` through the type checker to one in-repo declaration. Python resolves only a
bare name declared at module level in the same file, a bare name bound by `from <in-repo
module> import`, and `self.<name>()` to a method of the enclosing class or a base class
declared in the same file. Anything else is dropped, never guessed, and an edge whose target
has no symbol node is pruned. The caller is the enclosing function, method or class, or the
file for a module-level call. Each function, method and class gets `symbol_caller_count`
(distinct callers, recursion excluded) and `symbol_single_caller_helper` (1 when a
non-exported, non-dunder symbol has exactly one caller and it is a symbol). A callable with 2
or more resolved call sites also gets `symbol_constant_params`: parameters every site passes
the same literal, or none passes. Callers found only through unresolved calls are missing, so
a private method that tests call on an instance can read as a single-caller helper. These
metrics need edges from every file, so they are recomputed on each index. Under reuse, an
unchanged caller's edge to a callee that moved behind a re-export stays pruned until the
caller changes, as `references` edges do.

PageRank, relevance, and symbol coupling run at query time over one snapshot:

```ts
import {
  snapshotPageRank,
  snapshotRelevance,
  snapshotSymbolCoupling,
} from "@titan-design/code-graph";

snapshotPageRank(store, snapshotId); // global centrality over the file-level graph
snapshotPageRank(store, snapshotId, { personalization: new Map([[fileId, 1]]) }); // seeded
snapshotRelevance(store, snapshotId, [fileId]); // seeded over symmetrized edges
snapshotSymbolCoupling(store, snapshotId); // symbol pairs co-imported by 2+ files
```

The pure `computePageRank`, `computeRelevance`, `computeSymbolConsumers`, and
`computeSymbolCoupling` take node and edge arrays instead of a store.

### The `./analysis` subpath

`@titan-design/code-graph/analysis` re-exports the report, dashboard, and package-architecture
derivations below without the root's ts-morph, tree-sitter, and SQLite, so a browser bundle
can import it. `analysis/graph-report-browser-safe.test.ts` keeps its whole import closure
free of packages and Node builtins, and fails if the barrel re-exports a module it does not
check. `computeSymbolConsumers` and `buildSymbolCouplingPayload` are on it.

### Report sections and drift

Ported with TP-916 from codewatch's `graph report`, unchanged apart from import paths. All ten
are on the root and on `./analysis`, and are pure functions over rows the caller has already
read, so they run in a browser. Build one `ReportContext` per snapshot and window, then pass
it to every section:

```ts
import {
  buildReportContext,
  busFactorOf,
  computeReportDrift,
  hotspotScoreOf,
  topBusFactorRisks,
  topHotspots,
} from "@titan-design/code-graph/analysis";
import type { GraphNode } from "@titan-design/code-graph";

const nodes: GraphNode[] = [
  { id: "hot.ts", kind: "file", name: "hot.ts" },
  { id: "calm.ts", kind: "file", name: "calm.ts" },
];
const metric = (nodeId: string, name: string, value: number) => ({ nodeId, name, value, unit: "count" });
const metrics = [
  metric("hot.ts", "churn_30d", 12),
  metric("hot.ts", "cognitive_max", 9),
  metric("hot.ts", "bus_factor_30d", 1),
  metric("calm.ts", "churn_30d", 2),
  metric("calm.ts", "cognitive_max", 3),
  metric("calm.ts", "bus_factor_30d", 3),
];
const ctx = buildReportContext({ nodes, metrics, excluders: [], excludedRoles: new Set(), windowDays: 30 });

const hotspots = topHotspots(ctx, 10);
// [ { nodeId: 'hot.ts', churn: 12, complexity: 9, loc: 0, recency: 1, score: 108 },
//   { nodeId: 'calm.ts', churn: 2, complexity: 3, loc: 0, recency: 1, score: 6 } ]
const silos = topBusFactorRisks(ctx, 10);
// [ { nodeId: 'hot.ts', busFactor: 1, topAuthorShare: 1, churn: 12 } ]

const drift = computeReportDrift({
  baselineSnapshot, // the SnapshotRow the baseline rows were computed from
  currentHotspots: hotspots,
  baselineHotspots: [{ nodeId: "calm.ts", churn: 5, complexity: 4, loc: 0, recency: 1, score: 20 }],
  currentHotspotScore: (id) => hotspotScoreOf(ctx, id),
  currentSilos: silos,
  baselineSilos: [],
  currentBusFactor: (id) => busFactorOf(ctx, id),
  currentCoupling: [],
  baselineCoupling: [],
});
drift.improvedHotspots; // [ { nodeId: 'calm.ts', before: 20, after: 6, delta: -14 } ]
drift.newSilos; // [ { nodeId: 'hot.ts', churn: 12 } ]
```

- `buildReportContext(input)` indexes `nodes` by id and `metrics` by name, drops null values,
  and records the window and its metric suffix (`30d`, or `lifetime`).
- `keepNode(ctx, nodeId)` is the gate every section applies: a file node, not matched by
  `excluders`, not `generated`, and not in `excludedRoles`. `lookupMetric(ctx, name, nodeId)`
  reads one value, `undefined` when absent.
- `topHotspots(ctx, limit)` returns `HotspotRow[]` ranked by churn × complexity × recency,
  after Adam Tornhill and CodeScene. Complexity is `cognitive_max`, else `cyclomatic_max`;
  files with zero churn or complexity are left out. `hotspotScoreOf(ctx, nodeId)` is the same
  score for one file, 0 when it is filtered out or unscored.
- `topBusFactorRisks(ctx, limit)` returns `BusFactorRow[]`: files with a bus factor of 1 in
  the window, ranked by churn. `busFactorOf(ctx, nodeId)` reads one file's bus factor.
- `topTestCoverageRisks(ctx, limit)` returns `TestCoverageRow[]`: source files whose linked
  tests have a single author, ranked by `linked_test_count`.
- `topCentralFiles(nodes, edges, ctx, limit)` returns `CentralRow[]`, the top PageRank files
  that `keepNode` accepts.
- `computeReportDrift(input)` diffs current section rows against a baseline's into a
  `ReportDrift`: new, resolved, displaced, worsened, and improved hotspots; new, resolved, and
  displaced silos; new and intensified coupling pairs. Pass `baselineHotspotScore` to tell a
  newborn file from one that climbed into the ranking. `./analysis` also exports
  `hotspotComplexityOf`, which the root does not.

Coupling clusters stay in codewatch. Nothing here builds the report's `couplingClusters`
section, because codewatch's `topCouplingClusters` reads `git log` at report time, which a
browser cannot do. `computeReportDrift` only diffs the `CouplingRow[]` you pass in, and
`computeChangeCoupling` on `./history` gives the raw co-change pairs.

### Dashboard derivations

Ported with TP-918 from codewatch's `graph dashboard`, unchanged apart from import paths. All
are pure functions over rows the caller has already read, so they run in a browser:

- `collectNodeMetrics` folds metric rows into per-node `NodeMetrics`; `collectSymbolUtil`
  pairs symbol nodes with their utilization; `buildNodeMetrics`, `buildCentralFiles`,
  `buildHotExports`, and `buildBlastRadius` shape them for the files a `GraphReportResult`
  references (`referencedNodes`).
- `buildSymbolCouplingPayload` caps `computeSymbolCoupling` and `computeSymbolConsumers`
  into co-imported pairs and per-file consumer groups.
- `classifyCoupling` marks a co-changed pair hidden, expected, or unindexed against a
  `SnapshotContext`; build its `linkedPairs` with `pairKey`.
- `computeHealth` sums four capped penalties into a score out of 100 with its breakdown.
  Each component has a stable `key` and its `cap`. An optional second argument weighs
  them the caller's way; `DEFAULT_HEALTH_WEIGHTS` is the dashboard's.

### Context dossier and bundle

Ported with TP-1454 from codewatch's `graph context`, unchanged apart from import paths. All
three are deterministic projections of rows the caller has already read; no LLM is involved.

- `buildContextDossier(input)` shapes one file or symbol into a `ContextDossier`: metrics,
  churn, centrality, ownership, consumers split into source and test files, coupling
  partners, and blast radius. A file target lists its symbols, exports first, each with an
  `importance` that splits the file's centrality by utilization share. Symbol lines, the
  symbol target and blast-radius entries carry an optional `loc` read from the `symbol_loc`
  metric, which `collectNodeMetrics` folds onto the symbol's `loc`. The record carries
  `schemaVersion` (`CONTEXT_SCHEMA_VERSION`) so a store can invalidate old records.
- `renderContextMarkdown(dossier)` renders the same facts as markdown.
- `buildContextBundle(input)` wraps a dossier with the source text of the target's span (read
  from `repoRoot`, so this one touches the filesystem), its `references` and `imports` edges as
  explicit callers, dependencies, and coupling partners, and its `coverage_pct`. Pass
  `relevanceByFile` (from `computeRelevance`) and `targetFileId` to order edges by relevance
  to the target instead of by weight. `renderBundleText(bundle)` concatenates it for an
  embedder or an LLM.

### Unused exports and dead modules

Ported with TP-1467 from codewatch's `graph report`, unchanged apart from import paths. Both
are leads, not verdicts, and both drop files that `keepNode` rejects:

- `topUnusedExports(symbolNodes, publicApi, ctx, limit)` lists exported symbols whose
  `utilization` is 0 or absent, ranked internal first, then by `symbol_cognitive`
  descending, each row carrying the export's own `loc` (`symbol_loc`, 0 when unmeasured).
  A namespace import `import * as X` credits each export its member accesses name (`X.a`,
  the type `X.T`, `X["a"]`). Using `X` whole (an argument, a spread, `typeof X`) credits
  every export of an in-repo target.
  `publicApiFiles(nodes, edges)` builds `publicApi`: the files a `barrel`-role
  node re-exports one hop away, whose exports may still have npm consumers.
- `topDeadModules(nodes, edges, ctx, limit, { view })` lists files that a forward walk over
  `imports` and `re-exports` edges never reaches, ranked by `loc`. Files with the role `test`,
  `fixture`, `story` or `lab` are never rows. The default view, `"all-consumers"`, starts the
  walk from files with the role `entry`, `barrel`, `test`, `fixture`, `story`, `lab`, `script`
  or `config`, and from any `main.{ts,tsx,js,jsx}`. The `"public"` view starts it only from
  `entry`, `barrel`, `config`, `script` and `main.*` files. A row that test, story or lab
  files still reach carries `reachableOnlyFrom`, naming `lab` before `story` before `test`.

These differ from `pnpm dead:check`, which reads edges rather than `utilization` and follows
re-exports transitively from package-manifest entries.

### SCBench complexity rollup

TP-2474 h ports the complexity half of SlopCodeBench's code-quality metrics to TypeScript.
`qualitySection(nodes, ctx, packages, edges)` returns the report's optional `quality` section:
`complexity.total` over every kept file and `complexity.packages`, one row per `PackageRoot`
(`""` for files under none). `complexityDistribution(callables, packages)` and
`summarizeComplexity(callables)` are the same arithmetic over plain `CallableComplexity` rows.

Each named function with a `symbol_cyclomatic` metric is one callable; its SLOC is
`symbol_loc` minus `symbol_comment_lines`. Mass is CC·√SLOC. `erosion` (SCBench's
`mass.high_cc_pct`) is the share of mass in callables with CC above 10, and `cogErosion` is
the same over `symbol_cognitive`. The row also carries `ccMax`, `ccMean`, `ccStd` (population),
`ccHighCount` (CC > 10), `ccExtremeCount` (CC > 30), `highCcMean` and `ccGini`
(SCBench's `cc_concentration`). Nested closures and helpers with no symbol node of their own
are not counted, so erosion can read lower than a tool that measures every function, such as
scb-check. Splitting a function lowers erosion without improving the design, so read it beside
`symbol_pass_through` and `symbol_single_caller_helper`.

### SCBench dependency-graph metrics

TP-2474 i ports SlopCodeBench's dependency-graph measures. `quality.dependencies` holds one
`PackageDependencyRow` per package; `dependencyGraphMetrics(nodes, edges, packages)` builds the
rows from any node set, and `callGraphMetrics` and `importCyclicMass` are the same arithmetic
over plain `WeightedLink` lists. Only edges with both ends in one package count, and there is no
whole-tree row because propagation cost is O(n·(n + e)).

`calls` holds the call graph over the callables the complexity rollup measured, each edge
weighted by its call-site count:

- `cyclicDependencyMass` (`cyclic_dependency_mass`): the share of call weight on edges inside a
  strongly connected component of two or more callables. A function calling only itself is not
  a cycle.
- `propagationCost` (`propagation_cost`): ordered pairs (a, b), a ≠ b, with b reachable from a,
  over n(n − 1).
- `dependencyEntropy` (`dependency_entropy`): the mean over callables of the Shannon entropy of
  out-edge weights, normalized by log(out-degree), and 0 at out-degree 1 or less.

`imports` splits the cyclic mass of the package's file imports (edge `weight`, default 1).
`value` is the weight of value imports inside cycles that value imports close on their own, and
`typeOnly` is the rest of the cyclic weight, the part only a type-only import closes. Both share
the denominator of all import weight, so they sum to the cyclic mass of the whole import graph.

### Growth and untested risks

Ported with TP-1468 from codewatch's `graph report`, unchanged apart from import paths. Both
take a `ReportContext` and a limit, return `GrowthRiskRow[]` and `UntestedRiskRow[]`, and drop
files that `keepNode` rejects:

- `topGrowthRisks(ctx, limit)` lists files with a structural scaling smell: loop nesting of
  depth 2 or more, `recursive_functions`, or `search_in_loop`. It is a heuristic, not a Big-O
  bound. Ranked by `loop_depth`, then smell count.
- `topUntestedRisks(ctx, limit)` ranks `hotspot × (1 − coverage_pct / 100)`, where the hotspot
  score is churn × complexity, after Adam Tornhill and CodeScene. Files with no
  `coverage_pct` metric or full coverage are left out, so a repo with no coverage overlay
  gets an empty list.

### Partition quality

`computePartitionQuality` scores a package partition of the file graph: per-package cohesion,
Martin instability, an abstractness proxy (the share of `role: "types"` files), a layer label
(`top`, `middle`, `foundation`), pair coupling by intensity (`edges / files(from)`), and a
Newman-Girvan modularity Q over the whole partition.

```ts
import { computePartitionQuality, invertBuckets } from "@titan-design/code-graph";

const result = computePartitionQuality({ packages, fileByPackage, nodes, edges });
result.modularityQ; // 0.77 on titan-platform's packages/*
invertBuckets(fileByPackage); // file id -> package id, skipping the "" unassigned bucket
```

`resolveBarrels: true` rewrites an edge landing on a `role: "barrel"` file to the files it
re-exports, transitively. It over-attributes: one import of one name through a barrel becomes
one edge per re-export target, which is why it is off by default.

### Package architecture

Ported with TP-917 from codewatch's `graph arch`, unchanged apart from import paths.
`computeArch` aggregates a snapshot's file edges into package-to-package counts over a list
of `PackageRoot`s the caller supplies (codewatch detects them from `package.json` files; that
walk stays in codewatch). It drops test and fixture files, honours `exclude`, `excludeRole`,
`includeExternal` (one `EXTERNAL_BUCKET` node), and `minEdges`, and with `depth: "modules"` or
`maxPackageSize` drills packages over the threshold (`DEFAULT_MAX_PACKAGE_SIZE`, 30 files)
into sub-directory nodes. `bucketFilesByPackage` assigns file ids by longest package prefix,
with unmatched files under `""`. `filteredFileIds`, `aggregateEdges`, `toSortedEdges`, and
`packagesReferencedByEdges` are the steps it composes.

### Pruning snapshots

`planPrune` keeps the most recent `keep` snapshots (default 10) plus every snapshot whose ref
is in `keepRefs`; `runPrune` deletes the rest and reports row counts before and after.

```ts
import { planPrune, runPrune } from "@titan-design/code-graph";

planPrune(store, { keep: 10, keepRefs: ["main"] }); // { keep, remove }
runPrune(store, { keep: 10, vacuum: true }); // { plan, rowsBefore, rowsAfter, vacuumed }
```

The domain tables declare no foreign key, so `CodeGraphStore.deleteSnapshots` clears each of
`SNAPSHOT_SCOPED_TABLES` itself rather than relying on a cascade. `blob_cache` is
content-addressed and not snapshot-scoped, so a prune never drops a cached embedding.

## Protocol edges

`extractProtocolEdges(files)` reads source text (no index, no type checker) and returns the
runtime edges between files: `endpoints` (each HTTP route, SSE stream and MCP tool a server
declares), `edges` (one per caller file, serving file and endpoint, labelled `HTTP GET
/a/:id`, `SSE /events` or `MCP search`, with the caller's line) and `diagnostics`.

- HTTP: `x.get|post|put|patch|delete|all("/path", handler)` declares a route; `fetch(url,
  { method })` calls one. A template's run-time parts match any segment and a leading one (a
  base URL) is dropped. A route with a literal segment also matches under a mounted prefix;
  a route of parameters only must match the whole path.
- SSE: a route whose handler calls `streamSSE` or names `text/event-stream`; `new
  EventSource(url)` calls one.
- MCP: `server.tool("name", ...)` or `registerTool("name", ...)` declares a tool;
  `callTool({ name })` or `callTool("name")` calls one.

With no endpoint declared anywhere, `diagnostics` holds `NO_PROTOCOL_SOURCE`, and a map drawn
from the result (graph-layout's `emitRepoMap` with `protocolEdges`) reads "imports only".

## Conventions

"How does this repo do X, and where does code like this belong?" Ported from codewatch's
unmerged C-88 branch (TP-130). The layer cuts the barrel-resolved file graph into a few coarse
areas, has an injected summarizer describe each one, and ranks areas against a question by
embedding similarity. Verified against this release on this repo's `packages/`, with a fake
summarizer:

```ts
import { findConventions, getConventionMap, summarizeConventions } from "@titan-design/code-graph";

const summarizer = { model: "claude:sonnet", summarize: (prompt: string) => callYourLlm(prompt) };
await summarizeConventions(store, snapshotId, summarizer);
// { coverage: { files: 713, grouped: 513, areas: 24, summarized: 24 }, newlySummarized: 24, reused: 0, … }
// a second run: { newlySummarized: 0, reused: 24 }

getConventionMap(store, snapshotId, "claude:sonnet"); // the same areas, stored summaries only
await findConventions(store, snapshotId, "how are CLI commands registered?", embedder, "claude:sonnet");
// { matches: [ { label, summary, files: [ …up to 5 ], size, score }, … up to 3 ] }
```

- **The cut.** `detectCommunities` is greedy modularity (Clauset-Newman-Moore), not Leiden. It
  is deterministic without a seed: ties resolve by sorted id. `targetCount` keeps merging past
  the natural modularity stop until that many communities remain, and a size cap of twice the
  ideal share keeps a dense repo from collapsing into one area. The default target is one area
  per 25 files, clamped to 6..40. Areas under `minSize` (default 3) files are left unsummarized.
  Disconnected components never merge, so the component count is the floor.
- **Only the coarse level is summarized.** LLM cost is one call per area, and each summary is
  stored in `blob_cache` under `code-graph/community-summary`, keyed by `summarizer.model` and a
  hash of the prompt. The prompt carries the member files and their key exported signatures, so
  an area whose membership and signatures did not change is a cache hit in any snapshot. On
  this repo a finer cut (`targetCount: 60`) still reused 8 of its 35 areas.
- **The package ships no LLM client.** `Summarizer` is `{ model, summarize(prompt) }`; the
  product supplies it. `getConventionMap` and `findConventions` never call it. `findConventions`
  throws when no summary is stored for the model, and returns candidates with scores, not
  verdicts. Summary vectors go through the same embedding cache as similar symbols.

## Git history

Ported in TP-126, strictly as codewatch had it: churn over rolling windows, first-seen dates,
ownership and bus factor, and change coupling. The engine lives in `src/history/` and is
published on its own subpath. Its API is path-based: repo-relative posix paths in, plain
records out, no node ids or snapshots.

```ts
import { computeChangeCoupling, couplingFor, loadChurnEntries } from "@titan-design/code-graph/history";

const entries = loadChurnEntries({ repoRoot: ".", windowDays: 90 }) ?? []; // null outside git; throws if the log overflows
const { pairs, skippedLargeCommits } = computeChangeCoupling(entries);
couplingFor(pairs, "packages/code-graph/src/indexer.ts"); // partners by co-edit count
```

`indexPaths` writes history metrics on file nodes by default, through the
`history-metrics.ts` adapter, with codewatch's names: `churn_{w}`, `churn_{w}_commits`,
`churn_{w}_authors` and `recency_{w}` for each window, `file_age_days`, and `bus_factor_{w}`
plus `top_author_share_{w}` for the primary window. Windows default to 30, 90 and 180 days
plus `churnWindowDays` (the primary, default 30); `churnWindows` replaces the defaults and
`lifetime: true` adds an all-history window with its own ownership. `computeChurn: false`
turns all of it off. Outside git, or without a git binary, the index simply has no history
metrics. A git log that overflows its buffer (64 MiB for churn, 128 MiB for first-seen) or makes
git fail is not "outside git": `loadChurnEntries` and `loadFileFirstSeen` throw a `GitHistoryError`,
and `loadHistoryMetrics` returns it as `LoadedHistory.warnings`. `loadChurnResult` and
`loadFirstSeenResult` return `{ ok: false, reason: "not-git" | "overflow" | "git-error", detail }`.

Every git call finds the repo from its `repoRoot` with GIT_DIR, GIT_WORK_TREE and GIT_INDEX_FILE
stripped, so a hook's GIT_DIR never redirects it. Only when that finds no repo and GIT_DIR is set
(a work tree with no `.git`, its git dir elsewhere) do that call and every later one in `repoRoot`
use the caller's env. A `.git`-less work tree nested inside another repo resolves the outer repo.

Each index also writes function-level accretion on symbol nodes: `symbol_task_ids_{w}`, the
distinct task ids (`\b[A-Z][A-Z0-9]*-\d+\b` in commit subjects, or `taskIdPattern`) whose
commits edited the function, and `symbol_edit_commits_{w}`, for each of `accretionWindows`
(default `DEFAULT_ACCRETION_WINDOWS`, `[7]`; `[]` turns it off). One
`git log -p -U0 -M -C` over the widest window supplies the hunks. Each hunk's lines are carried
forward through every later commit's hunks on the same file, following renames, so an edit
made before lines were inserted above the function still lands on it at HEAD. An edit credits
the innermost symbol it overlaps, so a method edit does not count again for its class. A
threshold such as "3+ ids in 7 days" is a finding policy, not part of the metric. The patch
log has a 256 MiB buffer; overflow lands in `warnings` like the churn log's.
The carry assumes linear history: `--no-merges` reads commits in date order, so on a repo that
merges side branches an edit can be carried through mainline hunks that are not its ancestors
and land on the wrong lines. Squash- or rebase-merged repos are exact.

The adapter is exported from the package root, not from `./history`, because it speaks
`GraphMetric` and the seam below does not. A product that indexes on its own terms calls
`loadHistoryMetrics(nodes, idRoot, options)` for both the metric rows and the primary-window
churn entries they were built from (`LoadedHistory`, whose `warnings` say why history is missing or partial), with `HistoryMetricsOptions`,
`DEFAULT_CHURN_WINDOWS` (`[30, 90, 180]`), `resolveChurnWindows`, `windowSuffix` (`30d`,
`lifetime`) and `computeRecencyWindows` alongside it. Node ids are the history engine's
repo-relative paths, so both must be rooted at the same `idRoot`.

`revisionLineSource(repoRoot, rev)` is an evidence `LineSource` over the blobs of commit
`rev`, never the working tree, so `verifyCitation` over it reports `past-eof` for a range
that only an uncommitted edit reaches. `rev` must be a full 40-hex commit id; a ref name
throws. Each path is one `git --no-replace-objects cat-file --batch` read, cached. A path
that is not a blob at `rev` reads as unreadable.

Change coupling is not stored. It is computed on demand from `loadChurnEntries`, as
codewatch's `graph coupled` command did.

**The seam.** Nothing under `src/history/` imports the rest of code-graph; the rest may import
it. The `code-graph-history-seam` rule in `.codewatch/check.json` fails `pnpm dag:check` on
any such import. That keeps a later extraction into `@titan-design/git-history` a directory
move plus an import-path change.

**Behaviour kept from codewatch, gaps included.** A rename is followed only inside the commit
that made it, so a file's churn before the rename stays on its old path and is dropped.
First-seen dates come from a separate `--no-renames` pass, which makes a renamed file look
younger. `--since` resolves against git's clock while window slicing uses `nowEpoch`. History
metrics are recomputed on every index and never carried forward under reuse.

## Test linking and coverage

Ported in TP-133, strictly as codewatch had it. `linkTestsToSources` pairs each test file
with non-test files in two passes. Pass 1 uses path conventions: it strips a `.test` or `.spec`
infix and collapses a `__tests__/`, `test/` or `tests/` segment. A pytest file named
`test_<name>.py` or `<name>_test.py` that no path rewrite pairs goes to the one non-test
`<name>.py` in the tree, and to none when several share the name (TP-2170). Pass 2 gives a test that
pass 1 left unpaired its strongest co-edited non-test partner, with at least 2 shared commits.

`indexPaths` writes `linked_test_count` on each linked source, with or without git. With git
history on it also writes `test_bus_factor_{w}` and `test_top_author_share_{w}` for the
primary window. These summarize churn authorship across all tests linked to a source, so a
file can be well spread in production code and a single-author silo in its tests. All three
are recomputed on every index and never carried forward.

### Test kinds (Python)

Added in TP-2170 (`analysis/test-kinds.ts`). These are facts about code. Which code kinds
need which test kinds is policy, and it belongs to the consumer (codewatch's audit rules).
Every value is 0 or 1 unless it is a count.

- On each function outside a test file, written from the file's own bytes and carried
  forward under reuse: `symbol_kind_parser`, `symbol_kind_io`, `symbol_output_signal`
  (prints, writes stdout, argparse, a click, typer, Flask or FastAPI decorator, or a call in
  the file's `__main__` guard), `symbol_state_writes` (module state, `self`, `cls` or a
  parameter) and `symbol_unlisted_calls` (calls the purity allow-list does not cover).
- On each pytest test function, also carried forward: `test_kind_snapshot`,
  `test_kind_exact_output`, `test_kind_loose_output` (every output assertion is `in`,
  `startswith`, a length, a shape or truthiness), `test_kind_error_path`,
  `test_kind_property` and `test_kind_roundtrip`. An exit status of 0 is neither output nor
  an error path.
- Recomputed over the whole graph on every index: `symbol_kind_output_boundary` (the
  output signal, a `pyproject.toml` console script, or a module-level call in a
  `__main__.py`), and `symbol_kind_pure`, which means no parser and no I/O, output or
  global write in the function or anything it reaches through `calls` edges.
- For each source function some test reaches: `symbol_tests_snapshot`,
  `symbol_tests_exact_output`, `symbol_tests_loose_output_only`, `symbol_tests_error_path`,
  `symbol_tests_property` and `symbol_tests_roundtrip`. A test reaches what its `calls`
  edges reach. A click `CliRunner`'s `runner.invoke(cmd, ...)` counts as a call to `cmd` when
  the receiver is a `CliRunner()` or a name bound to or annotated as one; `invoke(cli, ["sub"])`
  credits the group `cli` only, and a target the test rebinds locally credits nothing. A test is credited
  only to what it reaches. Reach is one pass over the call graph's strongly connected
  components, with a bitset of tests flowing to callees.
- `symbol_kind_pure` needs every unlisted call resolved to a source function that is itself
  pure. An unresolved call (an external library, `input()`, `module.func()`) means not pure.
  Methods `str` shares with stateful types (`replace`, `copy`, `join`, `keys`) clear only on a
  receiver proven to be a str, list or dict value, so `Path.replace` and `s3.copy` do not.
  A local is a proven value only when every binding of it is a plain `name = expr` from a
  value: a for target, `with`/`except ... as`, unpacking, walrus, augmented assignment,
  match capture, import, `del`, `global` or `nonlocal` disqualifies it. Only value-typed
  builtins (`str`, `len`, `sorted`, `dict` and the like) yield a value; `getattr`, `max` and
  `next` do not. A function handed to `map`, `filter`, `functools.reduce` or `key=` counts as
  a call to it. A runner shadowed by a parameter or local of the same name is no runner.

`computeTestCoverageOwnership` lives in the `history-metrics.ts` adapter, not in
`src/history/`. It needs test links, and the seam forbids history from importing them.

```ts
import { attributeCoverage } from "@titan-design/code-graph";

// fileIdOf maps an absolute path to a file id, or null to skip; spans come from symbol nodes' attrs.
const metrics = attributeCoverage(istanbulReport, fileIdOf, symbolSpansByFile);
```

`attributeCoverage` turns an Istanbul `coverage-final.json` into `coverage_pct` metrics: one
per file (covered functions over total functions) and one per symbol, matched by line-range
containment to the innermost symbol. Coverage depends on which tests ran, not on file bytes,
so the index never writes or carries it. The caller stores it on the snapshot it measured,
as codewatch's `graph coverage` command does.
